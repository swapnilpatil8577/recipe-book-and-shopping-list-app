export class Ingredians{
    constructor(public name:string, public amount:number){}
}